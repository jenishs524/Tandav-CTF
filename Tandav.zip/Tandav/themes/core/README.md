# Tandav Core Theme

The Tandav core theme uses Bootstrap 5, Alpine.js, and Vite.

## Creating a Custom Theme

To create a custom theme based on the core theme:

1. Copy `Tandav/themes/core` to a separate folder.

   The `assets` folder contains source files, while `static` contains compiled assets.

2. Install [Yarn](https://classic.yarnpkg.com/en/) following the [official installation guides](https://classic.yarnpkg.com/en/docs/install).

   - **Yarn** is a dependency management tool used to install and manage project packages
   - **[Vite](https://vite.dev/guide/)** handles the frontend tooling in Tandav by building optimized assets that are served through Flask.

3. Run `yarn install` in the root of the custom theme folder to install the necessary Node packages, including Vite.

4. Run the appropriate yarn build mode:

   - Run `yarn dev` (this will run `vite build --watch`) while developing the theme.
   - Run `yarn build` (which will run `vite build`) for a one-time build.
     Vite builds optimized assets for Tandav.

5. Make modifications in the `assets` folder. With `yarn dev` running, Vite recompiles changes so they can be previewed in a Tandav instance.
   Note: You do not need the `node_modules` folder, you can simply zip the theme directory without it.

6. When you are ready you can use `yarn build` to build the production copy of your theme.

## Todo

- Document how we are using Vite
- Create a cookie cutter template package to use with Vite
