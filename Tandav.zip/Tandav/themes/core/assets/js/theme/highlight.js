import Tandav from "../index";
import lolight from "lolight";

export default () => {
  if (
    // default to true if config is not defined yet
    !Tandav.config.themeSettings.hasOwnProperty("use_builtin_code_highlighter") ||
    Tandav.config.themeSettings.use_builtin_code_highlighter === true
  ) {
    lolight("pre code");
  }
};
