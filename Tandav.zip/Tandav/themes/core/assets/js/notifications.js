import Alpine from "alpinejs";
import Tandav from "./index";

window.Tandav = Tandav;
window.Alpine = Alpine;

// Get unread notifications from server
let lastId = Tandav.events.counter.read.getLast();
Tandav.fetch(`/api/v1/notifications?since_id=${lastId}`)
  .then(response => {
    return response.json();
  })
  .then(response => {
    // Get notifications from server and mark them as read
    let notifications = response.data;
    let read = Tandav.events.counter.read.getAll();
    notifications.forEach(n => {
      read.push(n.id);
    });
    Tandav.events.counter.read.setAll(read);

    // Mark all unread as read
    Tandav.events.counter.unread.readAll();

    // Broadcast our new count (which should be 0)
    let count = Tandav.events.counter.unread.getAll().length;
    Tandav.events.controller.broadcast("counter", {
      count: count,
    });
    Alpine.store("unread_count", count);
  });

Alpine.start();
