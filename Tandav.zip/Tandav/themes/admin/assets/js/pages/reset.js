import "./main";
import $ from "jquery";
import { ezQuery } from "../compat/ezq";

function reset(event) {
  event.preventDefault();
  ezQuery({
    title: "Reset CTF?",
    body: "Are you sure you want to reset your Tandav instance?",
    success: function () {
      $("#reset-ctf-form").off("submit").submit();
    },
  });
}

$(() => {
  $("#reset-ctf-form").submit(reset);
});
