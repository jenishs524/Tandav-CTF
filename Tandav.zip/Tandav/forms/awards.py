from wtforms import RadioField, StringField, TextAreaField
from wtforms.fields.html5 import IntegerField

from Tandav.forms import BaseForm
from Tandav.forms.fields import SubmitField


class AwardCreationForm(BaseForm):
    name = StringField("Name")
    value = IntegerField("Value")
    category = StringField("Category")
    description = TextAreaField("Description")
    submit = SubmitField("Create")
    icon = RadioField(
        "Icon",
        choices=[
            ("", "None"),
            ("shield", "Shield"),
            ("bug", "Bug"),
            ("crown", "Crown"),
            ("crosshairs", "Crosshairs"),
            ("ban", "Ban"),
            ("lightning", "Lightning"),
            ("skull", "Skull"),
            ("brain", "Brain"),
            ("code", "Code"),
            ("cowboy", "Cowboy"),
            ("angry", "Angry"),
        ],
    )
