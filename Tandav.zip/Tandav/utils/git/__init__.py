from Tandav.utils.git.github import GitHubProvider
from Tandav.utils.git.gitlab import GitLabProvider
from Tandav.utils.git.provider import (  # noqa: F401
    CTFCLI_CONFIG_PATH,
    GitError,
    ctfcli_scaffold,
)

PROVIDERS = {
    GitHubProvider.id: GitHubProvider(),
    GitLabProvider.id: GitLabProvider(),
}


def get_provider(name):
    provider = PROVIDERS.get(name)
    if provider is None:
        raise GitError(f"Unknown git provider: {name}", status_code=404)
    return provider
