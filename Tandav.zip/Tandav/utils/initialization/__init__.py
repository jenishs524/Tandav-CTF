import datetime
import logging
import os
import sys

from flask import abort, redirect, render_template, request, session, url_for
from sqlalchemy.exc import IntegrityError, InvalidRequestError
from werkzeug.middleware.dispatcher import DispatcherMiddleware

from Tandav.cache import clear_user_recent_ips, clear_user_recent_tracking
from Tandav.exceptions import UserNotFoundException, UserTokenExpiredException
from Tandav.exceptions.email import UserResetPasswordTokenInvalidException
from Tandav.models import Tracking, db
from Tandav.utils import config, get_app_config, get_config, import_in_progress, markdown
from Tandav.utils.config import (
    can_send_mail,
    ctf_logo,
    ctf_name,
    ctf_theme,
    integrations,
    is_setup,
)
from Tandav.utils.config.pages import get_pages
from Tandav.utils.dates import isoformat, unix_time, unix_time_millis, unix_time_to_utc
from Tandav.utils.events import EventManager, RedisEventManager
from Tandav.utils.humanize.words import pluralize
from Tandav.utils.modes import generate_account_url, get_mode_as_word
from Tandav.utils.plugins import (
    get_configurable_plugins,
    get_menubar_plugins,
    get_registered_admin_scripts,
    get_registered_admin_stylesheets,
    get_registered_scripts,
    get_registered_stylesheets,
)
from Tandav.utils.security.auth import login_user, logout_user, lookup_user_token
from Tandav.utils.security.csrf import generate_nonce
from Tandav.utils.security.email import (
    generate_password_reset_token,
    verify_reset_password_token,
)
from Tandav.utils.user import (
    authed,
    get_current_team_attrs,
    get_current_user_attrs,
    get_current_user_recent_tracking,
    get_ip,
    get_locale,
    get_user_agent,
    is_admin,
)


def init_cli(app):
    from Tandav.cli import _cli

    app.register_blueprint(_cli, cli_group=None)


def init_template_filters(app):
    app.jinja_env.filters["markdown"] = markdown
    app.jinja_env.filters["unix_time"] = unix_time
    app.jinja_env.filters["unix_time_millis"] = unix_time_millis
    app.jinja_env.filters["unix_time_to_utc"] = unix_time_to_utc
    app.jinja_env.filters["isoformat"] = isoformat
    app.jinja_env.filters["pluralize"] = pluralize


def init_template_globals(app):
    from Tandav.constants import JINJA_ENUMS  # noqa: I001
    from Tandav.constants.assets import Assets
    from Tandav.constants.config import Configs
    from Tandav.constants.git import Git
    from Tandav.constants.languages import Languages
    from Tandav.constants.plugins import Plugins
    from Tandav.constants.sessions import Session
    from Tandav.constants.static import Static
    from Tandav.constants.teams import Team
    from Tandav.constants.users import User
    from Tandav.forms import Forms
    from Tandav.utils.config.visibility import (
        accounts_visible,
        challenges_visible,
        registration_visible,
        scores_visible,
    )
    from Tandav.utils.countries import get_countries, lookup_country_code
    from Tandav.utils.countries.geoip import lookup_ip_address, lookup_ip_address_city

    app.jinja_env.globals.update(config=config)
    app.jinja_env.globals.update(get_pages=get_pages)
    app.jinja_env.globals.update(can_send_mail=can_send_mail)
    app.jinja_env.globals.update(get_ctf_name=ctf_name)
    app.jinja_env.globals.update(get_ctf_logo=ctf_logo)
    app.jinja_env.globals.update(get_ctf_theme=ctf_theme)
    app.jinja_env.globals.update(get_menubar_plugins=get_menubar_plugins)
    app.jinja_env.globals.update(get_configurable_plugins=get_configurable_plugins)
    app.jinja_env.globals.update(get_registered_scripts=get_registered_scripts)
    app.jinja_env.globals.update(get_registered_stylesheets=get_registered_stylesheets)
    app.jinja_env.globals.update(
        get_registered_admin_scripts=get_registered_admin_scripts
    )
    app.jinja_env.globals.update(
        get_registered_admin_stylesheets=get_registered_admin_stylesheets
    )
    app.jinja_env.globals.update(get_config=get_config)
    app.jinja_env.globals.update(generate_account_url=generate_account_url)
    app.jinja_env.globals.update(get_countries=get_countries)
    app.jinja_env.globals.update(lookup_country_code=lookup_country_code)
    app.jinja_env.globals.update(lookup_ip_address=lookup_ip_address)
    app.jinja_env.globals.update(lookup_ip_address_city=lookup_ip_address_city)
    app.jinja_env.globals.update(accounts_visible=accounts_visible)
    app.jinja_env.globals.update(challenges_visible=challenges_visible)
    app.jinja_env.globals.update(registration_visible=registration_visible)
    app.jinja_env.globals.update(scores_visible=scores_visible)
    app.jinja_env.globals.update(get_mode_as_word=get_mode_as_word)
    app.jinja_env.globals.update(integrations=integrations)
    app.jinja_env.globals.update(authed=authed)
    app.jinja_env.globals.update(is_admin=is_admin)
    app.jinja_env.globals.update(get_current_user_attrs=get_current_user_attrs)
    app.jinja_env.globals.update(get_current_team_attrs=get_current_team_attrs)
    app.jinja_env.globals.update(get_ip=get_ip)
    app.jinja_env.globals.update(get_locale=get_locale)
    # TODO: Tandav 4.0 utcnow is deprecated and we should either update this to return TZ aware or rename entirely
    app.jinja_env.globals.update(utcnow=datetime.datetime.utcnow)
    app.jinja_env.globals.update(Assets=Assets)
    app.jinja_env.globals.update(Configs=Configs)
    app.jinja_env.globals.update(Plugins=Plugins)
    app.jinja_env.globals.update(Session=Session)
    app.jinja_env.globals.update(Static=Static)
    app.jinja_env.globals.update(Forms=Forms)
    app.jinja_env.globals.update(User=User)
    app.jinja_env.globals.update(Team=Team)
    app.jinja_env.globals.update(Languages=Languages)
    app.jinja_env.globals.update(Git=Git)

    # Add in JinjaEnums
    # The reason this exists is that on double import, JinjaEnums are not reinitialized
    # Thus, if you try to create two jinja envs (e.g. during testing), sometimes
    # an Enum will not be available to Jinja.
    # Instead we can just directly grab them from the persisted global dictionary.
    for k, v in JINJA_ENUMS.items():
        # .update() can't be used here because it would use the literal value k
        app.jinja_env.globals[k] = v


def init_logs(app):
    logger_submissions = logging.getLogger("submissions")
    logger_logins = logging.getLogger("logins")
    logger_registrations = logging.getLogger("registrations")

    logger_submissions.setLevel(logging.INFO)
    logger_logins.setLevel(logging.INFO)
    logger_registrations.setLevel(logging.INFO)

    log_dir = app.config["LOG_FOLDER"]
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    logs = {
        "submissions": os.path.join(log_dir, "submissions.log"),
        "logins": os.path.join(log_dir, "logins.log"),
        "registrations": os.path.join(log_dir, "registrations.log"),
    }

    try:
        for log in logs.values():
            if not os.path.exists(log):
                open(log, "a").close()

        submission_log = logging.handlers.RotatingFileHandler(
            logs["submissions"], maxBytes=10485760, backupCount=5
        )
        login_log = logging.handlers.RotatingFileHandler(
            logs["logins"], maxBytes=10485760, backupCount=5
        )
        registration_log = logging.handlers.RotatingFileHandler(
            logs["registrations"], maxBytes=10485760, backupCount=5
        )

        logger_submissions.addHandler(submission_log)
        logger_logins.addHandler(login_log)
        logger_registrations.addHandler(registration_log)
    except IOError:
        pass

    stdout = logging.StreamHandler(stream=sys.stdout)

    logger_submissions.addHandler(stdout)
    logger_logins.addHandler(stdout)
    logger_registrations.addHandler(stdout)

    logger_submissions.propagate = 0
    logger_logins.propagate = 0
    logger_registrations.propagate = 0


def init_events(app):
    if app.config.get("CACHE_TYPE") == "redis":
        app.events_manager = RedisEventManager()
    elif app.config.get("CACHE_TYPE") == "filesystem":
        app.events_manager = EventManager()
    else:
        app.events_manager = EventManager()
    app.events_manager.listen()


def init_request_processors(app):
    application_root = app.config.get("APPLICATION_ROOT")
    if application_root != "/":
        # Do application_root check first to prevent issues with cookie paths
        @app.before_request
        def force_subdirectory_redirect():
            if request.path.startswith(application_root) is False:
                return redirect(
                    application_root + request.script_root + request.full_path
                )

    @app.url_defaults
    def inject_theme(endpoint, values):
        if "theme" not in values and app.url_map.is_endpoint_expecting(
            endpoint, "theme"
        ):
            values["theme"] = ctf_theme()

    @app.before_request
    def needs_setup():
        if import_in_progress():
            if request.endpoint == "admin.import_ctf":
                return
            else:
                return "Import currently in progress", 403
        if is_setup() is False:
            if request.endpoint in (
                "views.setup",
                "views.integrations",
                "views.git.repository",
                "views.git.device",
                "views.git.device_token",
                "views.git.token",
                "views.git.repositories",
                "views.themes",
                "views.themes_beta",
                "views.files",
                "views.healthcheck",
                "views.robots",
            ):
                return
            else:
                return redirect(url_for("views.setup"))

    @app.before_request
    def tracker():
        if request.endpoint in ("views.themes", "views.themes_beta"):
            return

        if import_in_progress():
            if request.endpoint == "admin.import_ctf":
                return
            else:
                return "Import currently in progress", 403

        if authed():
            user_tracking = get_current_user_recent_tracking()
            ip = get_ip()
            user_agent = get_user_agent()

            track = None
            if (ip, user_agent) not in user_tracking or request.method in (
                "POST",
                "PATCH",
                "PUT",
                "DELETE",
            ):
                # Some database collations (e.g. MySQL's utf8mb4_unicode_ci) match user agents
                # differing in case/accents/trailing spaces so pick the exact match in Python
                # to stay consistent with the recent tracking cache
                tracks = Tracking.query.filter_by(
                    type=None,
                    ip=ip,
                    user_agent=user_agent,
                    user_id=session["id"],
                ).all()
                track = next((t for t in tracks if t.user_agent == user_agent), None)

                if track:
                    track.date = datetime.datetime.utcnow()
                else:
                    track = Tracking(
                        ip=ip,
                        user_agent=user_agent,
                        user_id=session["id"],
                    )
                    db.session.add(track)

            if track:
                try:
                    db.session.commit()
                except (InvalidRequestError, IntegrityError):
                    db.session.rollback()
                    db.session.close()
                    logout_user()
                else:
                    clear_user_recent_ips(user_id=session["id"])
                    clear_user_recent_tracking(user_id=session["id"])

    @app.before_request
    def banned():
        if request.endpoint in ("views.themes", "views.themes_beta"):
            return

        if authed():
            user = get_current_user_attrs()
            team = get_current_team_attrs()

            if user and user.banned:
                return (
                    render_template(
                        "errors/403.html", error="You have been banned from this CTF"
                    ),
                    403,
                )

            if team and team.banned:
                return (
                    render_template(
                        "errors/403.html",
                        error="Your team has been banned from this CTF",
                    ),
                    403,
                )

    @app.before_request
    def change_password():
        if request.endpoint in (
            "views.themes",
            "views.themes_beta",
            "auth.logout",
            "auth.reset_password",
        ):
            return

        if authed():
            user = get_current_user_attrs()

            if user and user.change_password:
                reset_token = session.get("reset_password")
                valid = False

                if reset_token:
                    try:
                        verify_reset_password_token(reset_token)
                        valid = True
                    except UserResetPasswordTokenInvalidException:
                        session.pop("reset_password")
                        valid = False

                if not valid:
                    reset_token = generate_password_reset_token(user.email)
                    session["reset_password"] = reset_token

                return redirect(url_for("auth.reset_password", data=reset_token))

    @app.before_request
    def tokens():
        token = request.headers.get("Authorization")
        if token and (
            request.is_json
            # Specially allow multipart/form-data for file uploads
            or (
                request.endpoint == "api.files_files_list"
                and request.method == "POST"
                and request.mimetype == "multipart/form-data"
            )
        ):
            try:
                token_type, token = token.split(" ", 1)
                user = lookup_user_token(token)
            except UserNotFoundException:
                abort(401, description="Your access token is invalid")
            except UserTokenExpiredException:
                abort(401, description="Your access token has expired")
            except Exception:
                abort(401, description="Invalid authorization header")
            else:
                if user.banned:
                    abort(403, description="You have been banned from this CTF")
                if user.team and user.team.banned:
                    abort(403, description="Your team has been banned from this CTF")
                login_user(user)

    @app.before_request
    def csrf():
        # TODO: Tandav 4.0 Consider reorganizing this function to only run on non safe methods
        # Early exit: no CSRF for functions explicitly marked as bypassing CSRF
        try:
            func = app.view_functions[request.endpoint]
        except KeyError:
            abort(404)
        if hasattr(func, "_bypass_csrf"):
            return
        # No CSRF for theme files using safe methods
        safe_methods = (
            "GET",
            "HEAD",
            "OPTIONS",
            "TRACE",
        )  # See RFC 7231, Section 4.2.1
        if (
            request.endpoint in ("views.themes", "views.themes_beta")
            and request.method in safe_methods
        ):
            return
        # No CSRF for API requests with an Authorization header
        if request.headers.get("Authorization"):
            return
        # Ensure a session and CSRF nonce are present
        if not session.get("nonce"):
            session["nonce"] = generate_nonce()
        if request.method not in safe_methods:
            if request.is_json:
                # API requests with JSON body => token in header
                if session["nonce"] != request.headers.get("CSRF-Token"):
                    abort(403)
            else:
                # Form submissions => token in form body
                if session["nonce"] != request.form.get("nonce"):
                    abort(403)

    @app.after_request
    def response_headers(response):
        response.headers["Cross-Origin-Opener-Policy"] = get_app_config(
            "CROSS_ORIGIN_OPENER_POLICY", default="same-origin-allow-popups"
        )
        return response

    if application_root != "/":
        app.wsgi_app = DispatcherMiddleware(app.wsgi_app, {application_root: app})
