from Tandav.utils.email.providers.mailgun import MailgunEmailProvider


def sendmail(addr, text, subject):
    print(
        "Tandav.utils.email.mailgun.sendmail will raise an exception in a future minor release of Tandav and then be removed in Tandav v4.0"
    )
    return MailgunEmailProvider.sendmail(addr, text, subject)
